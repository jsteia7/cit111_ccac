/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weeek4;

import java.util.Scanner;

/**
 *
 * @author Jake
 */
public class SpeedEnforcement {
    
     public static void main(String[] args) {
        // setup our speed limits
        final int MIN_SPEED = 40;
        final int MAX_SPEED = 55;
        // working speed variable
        int carSpeed;
        // create a Scanner object for getting car speed from console
        Scanner userInputScanner = new Scanner(System.in);
        // prompt user
        System.out.println("Enter speed of vehicle in mph and press enter:");
        // grab integer from console
        carSpeed = userInputScanner.nextInt();
        
        // implement decision logic
        if(carSpeed < MIN_SPEED) {
            System.out.println("Car is moving too slowly");
        } else if (carSpeed > MAX_SPEED){
            System.out.println("Car is traveling over the limit");
        } else {
            System.out.println("Car is within appropriate speed range");
        } // close chained if/else blocks
        
    }// close main method
}// close class SpeedEnforcement

