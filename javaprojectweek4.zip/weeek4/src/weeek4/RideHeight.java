/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weeek4;

import java.util.Scanner;

/**
 *
 * @author Jake
 */
public class RideHeight {
    // entry point for our program
    public static void main(String[] Args) {
        // create a rider mandatory minimum height
        final int MIN_HEIGHT_CM = 80;
        // declare the int-type variable to store the rider height
        int riderHeight;
        Scanner userInputScanner = new Scanner(System.in);
        // get the user or riders height
        System.out.println("Welcome to the Phantom Train ride! Enter your height in CM:");
        //read whatever the user typed on the keyboard into the variable riderHeight
       riderHeight = userInputScanner.nextInt();
        
        //compare the user's height against the height minimum 
        if(riderHeight < MIN_HEIGHT_CM){
            // code to run if the comparison evaluates to true (rider is too short)
            System.out.println("Sorry, Shorty- -come back when you grow some more");
        }else{
            // code to run if the comparison evaluates to true (rider is too short)
            System.out.println("Your height of " + riderHeight + "cm means you can ride!");
        }// close if/else block
        
    }//close main method
}//close class RideHeight 
   
